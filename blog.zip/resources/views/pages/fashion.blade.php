<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Andrea - Free Bootstrap 4 Template by Colorlib</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Lora:400,400i,700,700i&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Abril+Fatface&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/ionicons.min.css">

    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.timepicker.css">

    
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css">
  </head>
  <body>

	<div id="colorlib-page">
		<a href="#" class="js-colorlib-nav-toggle colorlib-nav-toggle"><i></i></a>
		<aside id="colorlib-aside" role="complementary" class="js-fullheight">
			<nav id="colorlib-main-menu" role="navigation">
				<ul>
					<li><a href="index.html">Home</a></li>
					<li class="colorlib-active"><a href="fashion.html">Fashion</a></li>
					<li><a href="travel.html">Travel</a></li>
					<li><a href="about.html">About</a></li>
					<li><a href="contact.html">Contact</a></li>
				</ul>
			</nav>

			<div class="colorlib-footer">
				<h1 id="colorlib-logo" class="mb-4"><a href="index.html" style="background-image: url(images/bg_1.jpg);">Andrea <span>Moore</span></a></h1>
				<div class="mb-4">
					<h3>Subscribe for newsletter</h3>
					<form action="#" class="colorlib-subscribe-form">
            <div class="form-group d-flex">
            	<div class="icon"><span class="icon-paper-plane"></span></div>
              <input type="text" class="form-control" placeholder="Enter Email Address">
            </div>
          </form>
				</div>
				<p class="pfooter"><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
	  Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="icon-heart" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Colorlib</a>
	  <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></p>
			</div>
		</aside> <!-- END COLORLIB-ASIDE -->
		<div id="colorlib-main">
			<section class="ftco-section">
				<div class="container">
					<div class="row px-md-4">
						<div class="col-md-12">
							<div class="blog-entry ftco-animate d-md-flex">
								<a href="single.html" class="img img-2" style="background-image: url(images/image_1.jpg);"></a>
								<div class="text text-2 pl-md-4">
		              <h3 class="mb-2"><a href="single.html">A Loving Heart is the Truest Wisdom</a></h3>
		              <div class="meta-wrap">
										<p class="meta">
		              		<span><i class="icon-calendar mr-2"></i>June 28, 2019</span>
		              		<span><a href="single.html"><i class="icon-folder-o mr-2"></i>Travel</a></span>
		              		<span><i class="icon-comment2 mr-2"></i>5 Comment</span>
		              	</p>
	              	</div>
		              <p class="mb-4">A small river named Duden flows by their place and supplies it with the necessary regelialia.</p>
		              <p><a href="#" class="btn-custom">Read More <span class="ion-ios-arrow-forward"></span></a></p>
		            </div>
							</div>
						</div>
						<div class="col-md-12">
							<div class="blog-entry ftco-animate d-md-flex">
								<a href="single.html" class="img img-2" style="background-image: url(images/image_2.jpg);"></a>
								<div class="text text-2 pl-md-4">
		              <h3 class="mb-2"><a href="single.html">Great Things Never Came from Comfort Zone</a></h3>
		              <div class="meta-wrap">
										<p class="meta">
		              		<span><i class="icon-calendar mr-2"></i>June 28, 2019</span>
		              		<span><a href="single.html"><i class="icon-folder-o mr-2"></i>Travel</a></span>
		              		<span><i class="icon-comment2 mr-2"></i>5 Comment</span>
		              	</p>
	              	</div>
		              <p class="mb-4">A small river named Duden flows by their place and supplies it with the necessary regelialia.</p>
		              <p><a href="#" class="btn-custom">Read More <span class="ion-ios-arrow-forward"></span></a></p>
		            </div>
							</div>
						</div>
						<div class="col-md-12">
							<div class="blog-entry ftco-animate d-md-flex">
								<a href="single.html" class="img img-2" style="background-image: url(images/image_3.jpg);"></a>
								<div class="text text-2 pl-md-4">
		              <h3 class="mb-2"><a href="single.html">Paths Are Made by Walking</a></h3>
		              <div class="meta-wrap">
										<p class="meta">
		              		<span>Dec 14, 2018</span>
		              		<span><a href="single.html">Lifestyle</a></span>
		              		<span>5 Comment</span>
		              	</p>
	              	</div>
		              <p class="mb-4">A small river named Duden flows by their place and supplies it with the necessary regelialia.</p>
		              <p><a href="#" class="btn-custom">Read More <span class="ion-ios-arrow-forward"></span></a></p>
		            </div>
							</div>
						</div>
						<div class="col-md-12">
							<div class="blog-entry ftco-animate d-md-flex">
								<a href="single.html" class="img img-2" style="background-image: url(images/image_4.jpg);"></a>
								<div class="text text-2 pl-md-4">
		              <h3 class="mb-2"><a href="single.html">The Secret of Getting Ahead is Getting Started</a></h3>
		              <div class="meta-wrap">
										<p class="meta">
		              		<span>Dec 14, 2018</span>
		              		<span><a href="single.html">Nature</a></span>
		              		<span>5 Comment</span>
		              	</p>
	              	</div>
		              <p class="mb-4">A small river named Duden flows by their place and supplies it with the necessary regelialia.</p>
		              <p><a href="#" class="btn-custom">Read More <span class="ion-ios-arrow-forward"></span></a></p>
		            </div>
							</div>
						</div>
						<div class="col-md-12">
							<div class="blog-entry ftco-animate d-md-flex">
								<a href="single.html" class="img img-2" style="background-image: url(images/image_5.jpg);"></a>
								<div class="text text-2 pl-md-4">
		              <h3 class="mb-2"><a href="single.html">You Can't Blame Gravity for Falling in Love</a></h3>
		              <div class="meta-wrap">
										<p class="meta">
		              		<span>Dec 14, 2018</span>
		              		<span><a href="single.html">Lifestyle</a></span>
		              		<span>5 Comment</span>
		              	</p>
	              	</div>
		              <p class="mb-4">A small river named Duden flows by their place and supplies it with the necessary regelialia.</p>
		              <p><a href="#" class="btn-custom">Read More <span class="ion-ios-arrow-forward"></span></a></p>
		            </div>
							</div>
						</div>
						<div class="col-md-12">
							<div class="blog-entry ftco-animate d-md-flex">
								<a href="single.html" class="img img-2" style="background-image: url(images/image_6.jpg);"></a>
								<div class="text text-2 pl-md-4">
		              <h3 class="mb-2"><a href="single.html">You Can't Blame Gravity for Falling in Love</a></h3>
		              <div class="meta-wrap">
										<p class="meta">
		              		<span>Dec 14, 2018</span>
		              		<span><a href="single.html">Travel</a></span>
		              		<span>5 Comment</span>
		              	</p>
	              	</div>
		              <p class="mb-4">A small river named Duden flows by their place and supplies it with the necessary regelialia.</p>
		              <p><a href="#" class="btn-custom">Read More <span class="ion-ios-arrow-forward"></span></a></p>
		            </div>
							</div>
						</div>
						<div class="col-md-12">
							<div class="blog-entry ftco-animate d-md-flex">
								<a href="single.html" class="img img-2" style="background-image: url(images/image_7.jpg);"></a>
								<div class="text text-2 pl-md-4">
		              <h3 class="mb-2"><a href="single.html">You Can't Blame Gravity for Falling in Love</a></h3>
		              <div class="meta-wrap">
										<p class="meta">
		              		<span>Dec 14, 2018</span>
		              		<span><a href="single.html">Travel</a></span>
		              		<span>5 Comment</span>
		              	</p>
	              	</div>
		              <p class="mb-4">A small river named Duden flows by their place and supplies it with the necessary regelialia.</p>
		              <p><a href="#" class="btn-custom">Read More <span class="ion-ios-arrow-forward"></span></a></p>
		            </div>
							</div>
						</div>
						<div class="col-md-12">
							<div class="blog-entry ftco-animate d-md-flex">
								<a href="single.html" class="img img-2" style="background-image: url(images/image_8.jpg);"></a>
								<div class="text text-2 pl-md-4">
		              <h3 class="mb-2"><a href="single.html">You Can't Blame Gravity for Falling in Love</a></h3>
		              <div class="meta-wrap">
										<p class="meta">
		              		<span><i class="icon-calendar mr-2"></i>June 28, 2019</span>
		              		<span><a href="single.html"><i class="icon-folder-o mr-2"></i>Travel</a></span>
		              		<span><i class="icon-comment2 mr-2"></i>5 Comment</span>
		              	</p>
	              	</div>
		              <p class="mb-4">A small river named Duden flows by their place and supplies it with the necessary regelialia.</p>
		              <p><a href="#" class="btn-custom">Read More <span class="ion-ios-arrow-forward"></span></a></p>
		            </div>
							</div>
						</div>
						<div class="col-md-12">
							<div class="blog-entry ftco-animate d-md-flex">
								<a href="single.html" class="img img-2" style="background-image: url(images/image_9.jpg);"></a>
								<div class="text text-2 pl-md-4">
		              <h3 class="mb-2"><a href="single.html">You Can't Blame Gravity for Falling in Love</a></h3>
		              <div class="meta-wrap">
										<p class="meta">
		              		<span><i class="icon-calendar mr-2"></i>June 28, 2019</span>
		              		<span><a href="single.html"><i class="icon-folder-o mr-2"></i>Travel</a></span>
		              		<span><i class="icon-comment2 mr-2"></i>5 Comment</span>
		              	</p>
	              	</div>
		              <p class="mb-4">A small river named Duden flows by their place and supplies it with the necessary regelialia.</p>
		              <p><a href="#" class="btn-custom">Read More <span class="ion-ios-arrow-forward"></span></a></p>
		            </div>
							</div>
						</div>
						<div class="col-md-12">
							<div class="blog-entry ftco-animate d-md-flex">
								<a href="single.html" class="img img-2" style="background-image: url(images/image_10.jpg);"></a>
								<div class="text text-2 pl-md-4">
		              <h3 class="mb-2"><a href="single.html">You Can't Blame Gravity for Falling in Love</a></h3>
		              <div class="meta-wrap">
										<p class="meta">
		              		<span>Dec 14, 2018</span>
		              		<span><a href="single.html">Lifestyle</a></span>
		              		<span>5 Comment</span>
		              	</p>
	              	</div>
		              <p class="mb-4">A small river named Duden flows by their place and supplies it with the necessary regelialia.</p>
		              <p><a href="#" class="btn-custom">Read More <span class="ion-ios-arrow-forward"></span></a></p>
		            </div>
							</div>
						</div>
						<div class="col-md-12">
							<div class="blog-entry ftco-animate d-md-flex">
								<a href="single.html" class="img img-2" style="background-image: url(images/image_11.jpg);"></a>
								<div class="text text-2 pl-md-4">
		              <h3 class="mb-2"><a href="single.html">You Can't Blame Gravity for Falling in Love</a></h3>
		              <div class="meta-wrap">
										<p class="meta">
		              		<span><i class="icon-calendar mr-2"></i>June 28, 2019</span>
		              		<span><a href="single.html"><i class="icon-folder-o mr-2"></i>Travel</a></span>
		              		<span><i class="icon-comment2 mr-2"></i>5 Comment</span>
		              	</p>
	              	</div>
		              <p class="mb-4">A small river named Duden flows by their place and supplies it with the necessary regelialia.</p>
		              <p><a href="#" class="btn-custom">Read More <span class="ion-ios-arrow-forward"></span></a></p>
		            </div>
							</div>
						</div>
						<div class="col-md-12">
							<div class="blog-entry ftco-animate d-md-flex">
								<a href="single.html" class="img img-2" style="background-image: url(images/image_12.jpg);"></a>
								<div class="text text-2 pl-md-4">
		              <h3 class="mb-2"><a href="single.html">You Can't Blame Gravity for Falling in Love</a></h3>
		              <div class="meta-wrap">
										<p class="meta">
		              		<span><i class="icon-calendar mr-2"></i>June 28, 2019</span>
		              		<span><a href="single.html"><i class="icon-folder-o mr-2"></i>Travel</a></span>
		              		<span><i class="icon-comment2 mr-2"></i>5 Comment</span>
		              	</p>
	              	</div>
		              <p class="mb-4">A small river named Duden flows by their place and supplies it with the necessary regelialia.</p>
		              <p><a href="#" class="btn-custom">Read More <span class="ion-ios-arrow-forward"></span></a></p>
		            </div>
							</div>
						</div>
					</div>
					<div class="row">
	          <div class="col text-center text-md-left">
	            <div class="block-27">
	              <ul>
	                <li><a href="#">&lt;</a></li>
	                <li class="active"><span>1</span></li>
	                <li><a href="#">2</a></li>
	                <li><a href="#">3</a></li>
	                <li><a href="#">4</a></li>
	                <li><a href="#">5</a></li>
	                <li><a href="#">&gt;</a></li>
	              </ul>
	            </div>
	          </div>
	        </div>
				</div>
			</section>
		</div><!-- END COLORLIB-MAIN -->
	</div><!-- END COLORLIB-PAGE -->

  <!-- loader -->
  <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>


  <script src="js/jquery.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/jquery.waypoints.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.animateNumber.min.js"></script>
  <script src="js/scrollax.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="js/google-map.js"></script>
  <script src="js/main.js"></script>
    
  </body>
</html>