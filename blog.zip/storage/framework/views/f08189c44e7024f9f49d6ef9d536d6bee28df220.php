<div class="sidebar-box ftco-animate">
    <h3 class="sidebar-heading">Tag Cloud</h3>
    <ul class="tagcloud">
        <a href="#" class="tag-cloud-link">animals</a>
        <a href="#" class="tag-cloud-link">human</a>
        <a href="#" class="tag-cloud-link">people</a>
        <a href="#" class="tag-cloud-link">cat</a>
        <a href="#" class="tag-cloud-link">dog</a>
        <a href="#" class="tag-cloud-link">nature</a>
        <a href="#" class="tag-cloud-link">leaves</a>
        <a href="#" class="tag-cloud-link">food</a>
    </ul>
</div>
<?php /**PATH /opt/lampp/htdocs/blog/resources/views/layouts/partials/tags.blade.php ENDPATH**/ ?>