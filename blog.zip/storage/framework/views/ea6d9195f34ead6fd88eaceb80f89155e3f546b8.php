<!DOCTYPE html>
<html lang="en">

<head>
    <title><?php echo $__env->yieldContent('title', "Amar Blog"); ?></title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Lora:400,400i,700,700i&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Abril+Fatface&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="<?php echo e(asset('template/css/open-iconic-bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('template/css/animate.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('template/css/owl.carousel.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('template/css/owl.theme.default.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('template/css/magnific-popup.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('template/css/aos.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('template/css/ionicons.min.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('template/css/bootstrap-datepicker.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('template/css/jquery.timepicker.css')); ?>">


    <link rel="stylesheet" href="<?php echo e(asset('template/css/flaticon.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('template/css/icomoon.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('template/css/style.css')); ?>">
    <link rel="stylesheet" href="http://cdn.bootcss.com/toastr.js/latest/css/toastr.min.css">

    <?php echo $__env->yieldPushContent('style'); ?>
</head>

<body>

    <?php echo $__env->yieldContent('master'); ?>


    <script src="<?php echo e(asset('template/js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('template/js/jquery-migrate-3.0.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('template/js/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('template/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('template/js/jquery.easing.1.3.js')); ?>"></script>
    <script src="<?php echo e(asset('template/js/jquery.waypoints.min.js')); ?>"></script>
    <script src="<?php echo e(asset('template/js/jquery.stellar.min.js')); ?>"></script>
    <script src="<?php echo e(asset('template/js/owl.carousel.min.js')); ?>"></script>
    <script src="<?php echo e(asset('template/js/jquery.magnific-popup.min.js')); ?>"></script>
    <script src="<?php echo e(asset('template/js/aos.js')); ?>"></script>
    <script src="<?php echo e(asset('template/js/jquery.animateNumber.min.js')); ?>"></script>
    <script src="<?php echo e(asset('template/js/scrollax.min.js')); ?>"></script>
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
    <script src="<?php echo e(asset('template/js/google-map.js')); ?>"></script>
    <script src="<?php echo e(asset('template/js/main.js')); ?>"></script>
    <script src="http://cdn.bootcss.com/jquery/2.2.4/jquery.min.js"></script>
    <script src="http://cdn.bootcss.com/toastr.js/latest/js/toastr.min.js"></script>
    <?php echo Toastr::message(); ?>


    <?php echo $__env->yieldPushContent('script'); ?>

</body>

</html>
<?php /**PATH /opt/lampp/htdocs/blog/resources/views/layouts/master.blade.php ENDPATH**/ ?>