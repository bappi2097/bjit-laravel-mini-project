<?php $__env->startSection('content'); ?>
    <div class="col-xl-8 py-5 px-md-5">
        <div class="row pt-md-4">
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-12">
                    <div class="blog-entry ftco-animate d-md-flex">
                        <a href="single.html" class="img img-2"
                            style="background-image: url(<?php echo e(asset($post->image)); ?>);"></a>
                        <div class="text text-2 pl-md-4">
                            <h3 class="mb-2"><a href="single.html"><?php echo e($post->title); ?></a></h3>
                            <div class="meta-wrap">
                                <p class="meta">
                                    <span><i
                                            class="icon-calendar mr-2"></i><?php echo e(date('F j, Y', strtotime($post->updated_at))); ?></span>
                                    <span><i class="icon-comment2 mr-2"></i>5 Comment</span>
                                </p>
                            </div>
                            <?php $__currentLoopData = $post->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span><a href="single.html"><i
                                            class="icon-folder-o mr-2"></i><?php echo e($category->name); ?></a></span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <p class="mb-4"><?php echo $post->summery; ?></p>
                            <p class="row justify-content-between">
                                <a href="#" class="btn-custom">Read More <span class="ion-ios-arrow-forward"></span></a>
                                <a href="<?php echo e(route('post.edit', $post->id)); ?>" class="btn btn-info">Edit</a>
                            </p>
                        </div>
                    </div>
                </div>
                
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div><!-- END-->
        <div class="row">
            <div class="col">
                <div class="block-27">
                    <?php echo e($posts->links()); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/blog/resources/views/pages/home.blade.php ENDPATH**/ ?>