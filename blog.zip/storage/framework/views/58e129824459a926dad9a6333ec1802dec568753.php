<div class="sidebar-box ftco-animate">
    <h3 class="sidebar-heading">Popular Articles</h3>
    <div class="block-21 mb-4 d-flex">
        <a class="blog-img mr-4" style="background-image: url(<?php echo e(asset('template/images/image_1.jpg')); ?>);"></a>
        <div class="text">
            <h3 class="heading"><a href="#">Even the all-powerful Pointing has no
                    control</a></h3>
            <div class="meta">
                <div><a href="#"><span class="icon-calendar"></span> June 28, 2019</a></div>
                <div><a href="#"><span class="icon-person"></span> Dave Lewis</a></div>
                <div><a href="#"><span class="icon-chat"></span> 19</a></div>
            </div>
        </div>
    </div>
    <div class="block-21 mb-4 d-flex">
        <a class="blog-img mr-4" style="background-image: url(<?php echo e(asset('template/images/image_2.jpg')); ?>);"></a>
        <div class="text">
            <h3 class="heading"><a href="#">Even the all-powerful Pointing has no
                    control</a></h3>
            <div class="meta">
                <div><a href="#"><span class="icon-calendar"></span> June 28, 2019</a></div>
                <div><a href="#"><span class="icon-person"></span> Dave Lewis</a></div>
                <div><a href="#"><span class="icon-chat"></span> 19</a></div>
            </div>
        </div>
    </div>
    <div class="block-21 mb-4 d-flex">
        <a class="blog-img mr-4" style="background-image: url(<?php echo e(asset('template/images/image_3.jpg')); ?>);"></a>
        <div class="text">
            <h3 class="heading"><a href="#">Even the all-powerful Pointing has no
                    control</a></h3>
            <div class="meta">
                <div><a href="#"><span class="icon-calendar"></span> June 28, 2019</a></div>
                <div><a href="#"><span class="icon-person"></span> Dave Lewis</a></div>
                <div><a href="#"><span class="icon-chat"></span> 19</a></div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /opt/lampp/htdocs/blog/resources/views/layouts/partials/popular.blade.php ENDPATH**/ ?>