<a href="#" class="js-colorlib-nav-toggle colorlib-nav-toggle"><i></i></a>
<aside id="colorlib-aside" role="complementary" class="js-fullheight">
    <nav id="colorlib-main-menu" role="navigation">
        <ul>
            <li class="colorlib-active"><a href="/">Home</a></li>
            <?php if(auth()->guard()->check()): ?>
                <li><a href="javascript::void(0)">Profile</a></li>
                <li><a href="<?php echo e(route('post.create')); ?>">Creae Post</a></li>
                <li><a href="<?php echo e(route('category.index')); ?>">Create Category</a></li>
                <li><a href="javascript::void(0)">Users</a></li>
                <li><a href="javascript::void(0)" onclick="document.querySelector('#logout').submit();">Logout</a></li>
                <form action="<?php echo e(route('logout')); ?>" method="post" id="logout">
                    <?php echo csrf_field(); ?>
                </form>
            <?php else: ?>
                <li><a href="<?php echo e(route('login')); ?>">Login</a></li>
            <?php endif; ?>
        </ul>
    </nav>

    
</aside> <!-- END COLORLIB-ASIDE -->
<?php /**PATH /opt/lampp/htdocs/blog/resources/views/layouts/partials/left-sidebar.blade.php ENDPATH**/ ?>