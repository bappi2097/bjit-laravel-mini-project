<?php $__env->startSection('title', 'Category | Blog'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-8">
            <div class="comment-form-wrap pt-5">
                <h3 class="mb-5">Category</h3>
                <form action="<?php echo e(route('category.store')); ?>" method="POST" class="p-3 p-md-5 bg-light">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="name">Name *</label>
                        <input type="text" class="form-control" id="name" name="name">
                    </div>
                    <div class="form-group">
                        <label for="slug">Slug *</label>
                        <input type="text" class="form-control" id="slug" name="slug">
                        <div class="form-group">
                            <input type="submit" value="Add Category" class="btn py-3 mt-4 px-4 btn-primary">
                        </div>
                </form>
            </div>
            <table class="table">
                <thead>
                    <tr>
                        <td>SL.</td>
                        <td>Name</td>
                        <td>Slug</td>
                        <td>Action</td>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($index + 1); ?></td>
                            <td><?php echo e($category->name); ?></td>
                            <td><?php echo e($category->slug); ?></td>
                            <td>
                                <a class="btn btn-outline-info"
                                    href="<?php echo e(route('category.edit', $category->id)); ?>">Edit</a>
                                <a class="btn btn-outline-danger" href="<?php echo e(route('category.destroy', $category->id)); ?>"
                                    onclick="event.preventDefault(); document.querySelector('#delete-<?php echo e($index); ?>').submit();">Delete</a>
                                <form id="delete-<?php echo e($index); ?>"
                                    action="<?php echo e(route('category.destroy', $category->id)); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="4">
                                <h1 class="text-center">No Data available</h1>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
    <script>
        (function() {
            document.querySelector('#name').addEventListener('input', (event) => {
                let name = event.target.value;
                if (name) {
                    document.querySelector('#slug').value = name.replace(/[^a-zA-Z0-9 -]/g, "").toLowerCase()
                        .split(" ").join(
                            '-');
                } else {
                    document.querySelector('#slug').value = "";
                }
            })
        }())
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/blog/resources/views/pages/category/index.blade.php ENDPATH**/ ?>