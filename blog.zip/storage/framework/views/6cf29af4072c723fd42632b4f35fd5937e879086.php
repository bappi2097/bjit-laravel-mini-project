<div class="sidebar-box ftco-animate">
    <h3 class="sidebar-heading">Categories</h3>
    <ul class="categories">
        <?php $__currentLoopData = \App\Category::withCount('posts')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><a href="#"><?php echo e($item->name); ?> <span>(<?php echo e($item->posts_count); ?>)</span></a></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php /**PATH /opt/lampp/htdocs/blog/resources/views/layouts/partials/categories.blade.php ENDPATH**/ ?>